#!/bin/bash

#generic install script
mkdir -p ~/.themes/test/arch-frost
mv $PWD/arch-frost/ ~/.themes/

mkdir -p ~/.themes/test/arch-frost-light
mv $PWD/arch-frost-light/ ~/.themes/

mkdir -p ~/.themes/test/arch-frost-shell
mv $PWD/arch-frost-shell/ ~/.themes/



