## Arch-Frost Theme

Numix-Frost theme customized with Arch in mind, with custom gnome-shell theme to match.

This is work in progress, shell-them based from the original EvoPop-Shell.
I am using a compiled (04-29-15) version, formatted manually and then edited. 

If you would like to grab the original source files, head on over to:
https://github.com/alex285/evopop-gnome-shell-theme

If you wish to grab the official version, head to:
https://github.com/alex285/evopop-shell-dist

Also, please check out the EvoPop GTK theme and Icons:

* https://github.com/solus-project/evopop-icon-theme
* https://github.com/solus-project/evopop-gtk-theme

GTK theme based from Numix-Frost theme, original sources in AUR
or available upon request.

Comments/Commits are always welcome!

-William




